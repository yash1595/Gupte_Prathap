/*
 * adc.h
 *
 *  Created on: Dec 3, 2018
 *      Author: yashm
 */

#include <stdint.h>
#ifndef INCLUDE_HEADERS_ADC_H_
#define INCLUDE_HEADERS_ADC_H_

void ADC_Init16b(void);

#endif /* INCLUDE_HEADERS_ADC_H_ */
