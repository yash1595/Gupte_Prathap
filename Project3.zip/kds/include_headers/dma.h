/*
 * dma.h
 *
 *  Created on: Dec 3, 2018
 *      Author: yashm
 */

#ifndef INCLUDE_HEADERS_DMA_H_
#define INCLUDE_HEADERS_DMA_H_

void dma_init(void);
#define DMA_BYTES	64

#endif /* INCLUDE_HEADERS_DMA_H_ */
